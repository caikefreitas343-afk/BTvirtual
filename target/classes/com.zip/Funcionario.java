package com.biblioteca.entity;

import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_bibliotecario")
public class Funcionario extends Usuario {
    
	private String cargo;
    private String setor;

    protected Funcionario() {
        super();
        this.tipoUsuario = TipoUsuario.BIBLIOTECARIO;
    }

    // Construtor vazio (Obrigatorio para o JPA)

    public Funcionario(UUID id, String nome, String matricula, String email, String senha, String cargo, String setor) {
        this(id, nome, matricula, email, senha, cargo, setor, TipoUsuario.BIBLIOTECARIO);
    }

    public Funcionario(UUID id, String nome, String matricula, String email, String senha, String cargo, String setor, TipoUsuario tipoUsuario) {
        super(id, nome, matricula, email, senha, tipoUsuario != null ? tipoUsuario : TipoUsuario.BIBLIOTECARIO);
        this.cargo = cargo;
        this.setor = setor;
    }

    // Getters e Setters
    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }
}

